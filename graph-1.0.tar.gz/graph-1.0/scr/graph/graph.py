import pyqtgraph as pg
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *

class XY_Plane(QMainWindow):
    def __init__(self, x_width, y_width):
        super().__init__()
        self.resize(x_width, y_width)
        self.setWindowTitle("Function Graph")
        self.sliders = list()
        self.slider_value = 0

        self.plot_graph = pg.PlotWidget()
        self.plot_graph.showGrid(x=True, y=True)
        self.plot_graph.setBackground("w")
        self.setMinMax(0,10,0,10)

        self.setCentralWidget(self.plot_graph)

    def addGraph(self, function, width=3, color=(0,0,0), style=Qt.SolidLine):
        accuracy = 30
        x_num = list()
        y_num = list()
        for i in range(accuracy*(self.max_x-self.min_x)):
            num = (i/accuracy) + self.min_x
            x_num.append(num)
        for i in range(len(x_num)):
            try:
                result = function(x_num[i])
                y_num.append(result)
            except:
                x_num.remove(x_num[0])

        self.pen = pg.mkPen(color=color, width=width, style=style)
        self.plot_graph.plot(
            x_num,
            y_num,
            pen=self.pen,
        )

    def addPoint(self, x, y, color="b", size=15):
        self.plot_graph.plot(
            [x],
            [y], 
            symbol="o",
            symbolSize=size,
            symbolBrush=color,
        )

    def setMinMax(self, min_x, max_x, min_y, max_y):
        self.min_x = min_x
        self.max_x = max_x
        self.min_y = min_y
        self.max_y = max_y
        self.plot_graph.setXRange(min_x, max_x)
        self.plot_graph.setYRange(min_y, max_y)